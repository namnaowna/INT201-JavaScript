function display(content) {
  if (content === undefined || content === null){
    return 'no message'
  }else {
    return 'your message is ' + content
  }
  
}

module.exports = display
