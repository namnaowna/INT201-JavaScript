[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/_4JPKCX3)
# test-demo

writing the function _display(content)_ to return a concatenated message using the 'your message is ' string and the content parameter."

# Output

- display('hello world!') -> your message is hello world!
- display('123') -> your message is 123
- display(null) -> no message
- display(undefined) ->no message
