const { template } = require('@babel/core')

function totalPages(arrayItems, rowsPerPage) {
  // if (typeof rowsPerPage !== 'number' || rowsPerPage <= 0){
  //   return 1
  if ( rowsPerPage === null || rowsPerPage === undefined || rowsPerPage === 0){
    return 1
  } else if (arrayItems === null || arrayItems === undefined) { 
      return undefined
  }
   
    const itemcount = arrayItems.length;
    const totalPages = Math.ceil(itemcount / rowsPerPage)

    return totalPages;

}

module.exports = totalPages
