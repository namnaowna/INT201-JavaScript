//4. create array with Array.of() function
const x = Array.of(5)
const y = Array.of(1, 5, 7)
const z = Array.of(true, "A", "JS")

console.log(x.length) //1
console.log(y.length) //3
console.log(z.length) //3
