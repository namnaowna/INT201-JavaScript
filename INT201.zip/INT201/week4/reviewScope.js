// function doSomething(msg) {
//     console.log(x)
//     if (msg === null || msg === undefined) {
//       let someone = 'guest'
//     }
//     let x = 1
//     //   console.log(someone)
//     return `hello, ${msg}`
//   }
//   doSomething()
//   // console.log(msg)

var x = 1
if (x === 1) {
  var x = "unknown"
  console.log(x)
}
console.log(x)
