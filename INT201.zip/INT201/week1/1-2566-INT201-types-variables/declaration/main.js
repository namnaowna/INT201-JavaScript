// introduce var, let, and const
var x = 0
var z,
  y = 1

let i = 5
let sum,
  avg = 0
const DOLLAR_2_BAHT = 35.32

console.log(x) //0
console.log(y) //1
console.log(z) //undefined
console.log(i) //5
console.log(sum) //undefined
console.log(avg) //0
console.log(DOLLAR_2_BAHT) //35.32

let deposit = 1n

console.log(typeof deposit)
console.log(typeof 1)
