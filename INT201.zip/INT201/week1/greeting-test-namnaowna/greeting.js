function greeting(someone) {
  console.log(result) //code here!
}

module.exports = greeting
