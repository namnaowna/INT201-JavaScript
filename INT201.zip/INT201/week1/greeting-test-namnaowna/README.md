[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/veIdkfdP)
# test-demo

Writing the function named _greeting(someone)_ to return a greeting message that starts with 'hello, ' and follows with _someone_ parameter.

# Output

![Expected Output](/images/CaptureOutput.JPG)
