function greeting(someone) {
  const greet = `hello, ${someone}`
  return greet
}
const result = greeting("Thamonwan")
console.log(result)
